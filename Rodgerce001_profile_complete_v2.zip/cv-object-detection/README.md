# 🔍 Computer Vision — Object Detection
Starter CV project using OpenCV.

### 🔧 Setup
```bash
pip install -r requirements.txt
python detect.py
```

🤖 Future goals: YOLO webcam detection!
