# 🤖 Chatbot NLP
A simple rule-based chatbot written in Python.

### 🔧 Setup
```bash
pip install -r requirements.txt
python main.py
```

📌 More features coming soon!
