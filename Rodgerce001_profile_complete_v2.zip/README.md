# Hi, I'm **Rodgerce Ojwang** 👋

💻 **AI & Machine Learning Enthusiast**  
🎯 Passionate about building intelligent systems and solving real‑world problems  
🌱 Currently learning: Deep Learning, Computer Vision, NLP  
🚀 Open to collaborations in AI/ML projects

---

### 🧠 Skills
- **Programming:** Python, C++, JavaScript, HTML/CSS
- **Machine Learning:** Scikit‑Learn, TensorFlow (Learning), Data Preprocessing
- **Tools & Platforms:** GitHub, VS Code, Jupyter Notebook

---

### 📌 Featured Projects
| Project | Description | Repo Link |
|--------|-------------|-----------|
| 🤖 Chatbot NLP | Rule-based chatbot using Python | Coming soon |
| 🔍 Object Detection | Simple object detection model | Coming soon |
| 📈 ML Predictor | Machine learning prediction sample | Coming soon |
| 🌐 Portfolio Website | Personal portfolio using HTML/CSS/JS | Coming soon |

---

### 📫 Find Me Online
📧 **Email:** rodgerceojwang@gmail.com

✨ *Let’s build the future with AI!* ✨
