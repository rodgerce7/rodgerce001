# 🌐 Personal Portfolio Website
A clean and responsive portfolio built with HTML, CSS & JavaScript.

### 🔧 Run Locally
Open:
```
index.html
```

✅ Deployable on GitHub Pages!
