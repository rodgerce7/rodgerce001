# 📈 ML Predictor
Machine Learning example project using Scikit‑Learn.

### 🔧 Setup
```bash
pip install -r requirements.txt
python model.py
```

✅ Future additions: better models!
